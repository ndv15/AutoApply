_seen=set()
def seen(key:str)->bool: return key in _seen
def mark(key:str): _seen.add(key)
