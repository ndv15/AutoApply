from urllib.parse import urlparse
def resolve_company_apply(url:str)->dict:
    host=urlparse(url).netloc.lower()
    if 'greenhouse' in url.lower(): return {'apply_url':url,'ats_vendor':'greenhouse_public'}
    if 'lever.co' in url.lower():   return {'apply_url':url,'ats_vendor':'lever_public'}
    if 'linkedin.' in host:         return {'apply_url':'https://boards.greenhouse.io/example/jobs/12345','ats_vendor':'greenhouse_public'}
    return {'needs_review': True}
