from pydantic import BaseModel
import yaml

class Settings(BaseModel):
    thresholds: dict
    discovery: dict
    apply: dict
    security: dict
    notifications: dict
    ui: dict
    telemetry: dict
    research: dict

def load_settings(path: str='config.yaml')->Settings:
    with open(path,'r') as f:
        return Settings(**yaml.safe_load(f))
