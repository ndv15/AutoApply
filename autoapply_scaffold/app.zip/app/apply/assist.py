def open_assist(apply_url:str)->dict:
    return {'mode':'assist','apply_url':apply_url,'message':'Open URL and submit manually.'}
