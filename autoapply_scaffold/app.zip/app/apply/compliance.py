def allowed_for_auto(ats_vendor:str)->bool:
    return ats_vendor in ('greenhouse_public','lever_public')
