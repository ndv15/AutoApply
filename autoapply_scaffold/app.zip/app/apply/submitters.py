def auto_submit(ats_vendor, apply_url):
    if ats_vendor not in ('greenhouse_public','lever_public'):
        return {'ok':False,'reason':'Not allow-listed'}
    return {'ok':True,'receipt_id':'R-'+ats_vendor+'-0001'}
