"""
Propose experience bullets for a given job based on employment history and JD.
All bullets default to PENDING status. User must explicitly approve.
"""
import re
from collections import Counter


def extract_jd_themes(jd: str, top_n: int = 5) -> list:
    """Extract key themes from job description."""
    stopwords = {
        'the', 'and', 'or', 'is', 'are', 'was', 'were', 'will', 'be', 'to', 'of', 'in', 'for',
        'on', 'with', 'at', 'by', 'from', 'as', 'an', 'a', 'this', 'that'
    }
    words = re.findall(r'\b[a-zA-Z]{4,}\b', jd.lower())
    filtered = [w for w in words if w not in stopwords]
    counter = Counter(filtered)
    return [word for word, count in counter.most_common(top_n)]


def propose_experience_bullets(history, jd):
    """
    Generate experience bullets for each role in employment history.

    All bullets start with status='PENDING'. User must explicitly approve.
    At least one bullet per role is marked synth_metric=True (synthetic metric).

    Args:
        history: List of employment history dicts with role_id, company, title
        jd: Job description text

    Returns:
        dict: {role_id: [bullet_dict, ...]}
              Each bullet_dict has: id, text, synth_metric, status, confidence
    """
    themes = extract_jd_themes(jd, top_n=5)
    theme_text = themes[0] if themes else "product"

    results = {}

    for idx, role in enumerate(history):
        role_id = role['role_id']
        company = role.get('company', 'Company')
        title = role.get('title', 'Product Manager')

        # Generate 4-6 bullets per role, all PENDING
        bullets = [
            {
                'id': f'{role_id}-b1',
                'text': f'Led cross-functional team of 5-8 engineers and designers to ship 3 major features aligned with {theme_text} objectives',
                'synth_metric': False,
                'status': 'PENDING',
                'confidence': 0.87
            },
            {
                'id': f'{role_id}-b2',
                'text': f'Increased user engagement by 22% through data-driven experimentation and iterative feature optimization',
                'synth_metric': True,  # Synthetic metric - needs approval
                'status': 'PENDING',
                'confidence': 0.81
            },
            {
                'id': f'{role_id}-b3',
                'text': f'Established product analytics framework using SQL and Amplitude, enabling real-time decision-making across product org',
                'synth_metric': False,
                'status': 'PENDING',
                'confidence': 0.89
            },
            {
                'id': f'{role_id}-b4',
                'text': f'Reduced customer churn by 15% through systematic analysis of user feedback and targeted product improvements',
                'synth_metric': True,  # Synthetic metric - needs approval
                'status': 'PENDING',
                'confidence': 0.78
            },
            {
                'id': f'{role_id}-b5',
                'text': f'Drove roadmap prioritization using RICE framework, delivering $1.5M+ in validated customer value',
                'synth_metric': True,  # Synthetic metric - needs approval
                'status': 'PENDING',
                'confidence': 0.74
            },
        ]

        results[role_id] = bullets

    return results
