"""
Skills suggestion engine with curated allow-list and alias matching.
Never auto-adds skills. All suggestions go to needs_confirmation.
"""
import re


def propose_skills(jd: str, registry: dict):
    """
    Propose skills based on JD analysis and registry.

    Returns ONLY needs_confirmation (never auto_added).
    Provides explanation for each suggested skill.

    Args:
        jd: Job description text
        registry: Dict with 'approved', 'rejected', 'aliases' keys

    Returns:
        tuple: (auto_added: list, needs_confirmation: list of dicts)
               Each needs_confirmation item: {skill, reason, match_type}
    """
    approved = set(registry.get('approved', []))
    rejected = set(registry.get('rejected', []))
    aliases = registry.get('aliases', {})

    # Build allow-list from approved + alias keys
    allow_list = set(approved)
    for alias_key in aliases.keys():
        allow_list.add(alias_key)

    # Extract candidate tokens from JD (title-case, 3+ chars)
    jd_tokens = set(re.findall(r'\b[A-Za-z]{3,}\b', jd))
    jd_tokens_titled = {t.title() for t in jd_tokens}

    suggestions = []

    # 1. Direct allow-list matches
    for skill in allow_list:
        if skill in jd_tokens_titled and skill not in approved:
            suggestions.append({
                'skill': skill,
                'reason': f'Direct match in JD and present in skill registry',
                'match_type': 'direct'
            })

    # 2. Alias matches
    for alias_key, alias_values in aliases.items():
        for alias_val in alias_values:
            # Check if alias phrase appears in JD
            if alias_val.lower() in jd.lower() and alias_key not in approved:
                suggestions.append({
                    'skill': alias_key,
                    'reason': f'Matched via alias "{alias_val}" in JD',
                    'match_type': 'alias'
                })
                break  # Only add once per alias_key

    # 3. Curated skill keywords (common tech/PM skills)
    curated_skills = {
        'Python', 'JavaScript', 'React', 'SQL', 'AWS', 'Docker', 'Git',
        'Agile', 'Scrum', 'Jira', 'Figma', 'Tableau', 'Looker',
        'Product Management', 'Data Analysis', 'A/B Testing', 'User Research',
        'Roadmapping', 'Stakeholder Management', 'Analytics'
    }

    for skill in curated_skills:
        # Check if skill or lowercase version appears in JD
        if (skill in jd or skill.lower() in jd.lower()) and skill not in approved and skill not in rejected:
            # Check if not already suggested
            if not any(s['skill'] == skill for s in suggestions):
                suggestions.append({
                    'skill': skill,
                    'reason': f'Curated skill matched in JD',
                    'match_type': 'curated'
                })

    # Deduplicate and limit
    seen = set()
    unique_suggestions = []
    for sugg in suggestions:
        if sugg['skill'] not in seen and sugg['skill'] not in rejected:
            seen.add(sugg['skill'])
            unique_suggestions.append(sugg)

    # Limit to top 8 suggestions
    needs_confirmation = unique_suggestions[:8]

    # NEVER auto-add anything
    auto_added = []

    return auto_added, needs_confirmation
