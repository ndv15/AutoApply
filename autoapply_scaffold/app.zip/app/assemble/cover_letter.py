from docx import Document
from pathlib import Path
def render_cover(path: Path, company, role, summary):
    doc=Document()
    doc.add_paragraph(f"Dear Hiring Team at {company},")
    doc.add_paragraph(summary)
    doc.add_paragraph("Sincerely,"); doc.add_paragraph("{{NAME}}")
    doc.save(path); return path
