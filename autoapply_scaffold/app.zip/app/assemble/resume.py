from docx import Document
from pathlib import Path
def render_resume(path: Path, identity, summary, soq, experience, skills):
    doc=Document()
    doc.add_heading(identity['name'], level=1)
    doc.add_paragraph(f"{identity['location']} | {identity['email']} | {identity['phone']} | {identity['linkedin']}")
    doc.add_heading('Executive Summary', level=2); doc.add_paragraph(summary)
    doc.add_heading('Summary of Qualifications', level=2)
    for s in soq: doc.add_paragraph(s, style='List Bullet')
    doc.add_heading('Experience', level=2)
    for role_id, bullets in experience.items():
        doc.add_paragraph(role_id)
        for b in bullets:
            if b.get('status')=='APPROVED':
                doc.add_paragraph(b['text'], style='List Bullet')
    doc.add_heading('Skills', level=2); doc.add_paragraph(', '.join(skills))
    doc.save(path); return path
